SELECT 
	products.Product_Category, SUM(sales.Units) as Total_Units_Sold
FROM
    sales AS sales 
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GRoup BY
	products.Product_Category
ORDER BY
	Total_Units_Sold DESC;
	