SELECT
    strftime('%Y-%m', sales.Date) AS Month,
    SUM(sales.Units * CAST(REPLACE(products.Product_Price, '$', '') AS DECIMAL)) AS Total_Revenue,
    (
        SELECT
            SUM(sales_inner.Units * CAST(REPLACE(products.Product_Price, '$', '') AS DECIMAL))
        FROM
            sales AS sales_inner
        JOIN
            products AS products_inner ON sales_inner.Product_ID = products_inner.Product_ID
        WHERE
            strftime('%Y-%m', sales_inner.Date) = strftime('%Y-%m', DATE(sales.Date, '-1 month'))
    ) AS Previous_Month_Revenue,
    (
        (SUM(sales.Units * CAST(REPLACE(products.Product_Price, '$', '') AS DECIMAL)) -
        (
            SELECT
                SUM(sales_inner.Units * CAST(REPLACE(products.Product_Price, '$', '') AS DECIMAL))
            FROM
                sales AS sales_inner
            JOIN
                products AS products_inner ON sales_inner.Product_ID = products_inner.Product_ID
            WHERE
                strftime('%Y-%m', sales_inner.Date) = strftime('%Y-%m', DATE(sales.Date, '-1 month'))
        )) /
        (
            SELECT
                SUM(sales_inner.Units * CAST(REPLACE(products.Product_Price, '$', '') AS DECIMAL))
            FROM
                sales AS sales_inner
            JOIN
                products AS products_inner ON sales_inner.Product_ID = products_inner.Product_ID
            WHERE
                strftime('%Y-%m', sales_inner.Date) = strftime('%Y-%m', DATE(sales.Date, '-1 month'))
        )
    ) * 100 AS Growth_Percentage
FROM
    sales
JOIN
    products ON sales.Product_ID = products.Product_ID
GROUP BY
    strftime('%Y-%m', sales.Date)
ORDER BY
    Month;
