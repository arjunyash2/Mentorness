SELECT 
	sales.Store_ID,
    stores.Store_Name,
    SUM(sales.units * products.product_price) as Revenue
FROM
    sales AS sales 
    JOIN
    	stores as stores on sales.Store_ID = stores.Store_ID
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GRoup BY
	sales.Store_ID, stores.Store_Name
ORDER BY
	Revenue ASC LIMIT 3;
    
    
    
SELECT 
	sales.Store_ID,
    stores.Store_Name,
    SUM(sales.units * products.product_price) as Revenue
FROM
    sales AS sales 
    JOIN
    	stores as stores on sales.Store_ID = stores.Store_ID
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GRoup BY
	sales.Store_ID, stores.Store_Name
ORDER BY
	Revenue DESC
