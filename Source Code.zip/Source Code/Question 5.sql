SELECT 
	sales.Store_ID,
    stores.Store_Name,
    SUM(sales.units * products.product_price) as Revenue,
    strftime('%Y-%m', sales.Date) AS Month
FROM
    sales AS sales 
    JOIN
    	stores as stores on sales.Store_ID = stores.Store_ID
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GRoup BY
	sales.Store_ID, stores.Store_Name, Month
ORDER BY
	Month, stores.Store_Name