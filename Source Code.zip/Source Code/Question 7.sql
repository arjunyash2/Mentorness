SELECT 
    products.Product_ID,
    products.Product_Name,
    products.Product_Cost AS 'Product_Cost',
    products.Product_Price AS 'Selling_Price',
    SUM(sales.units * products.product_price) AS Total_Revenue,
    SUM(sales.Units * products.Product_Cost) AS Total_Cost,
    SUM(sales.units * products.product_price) - SUM(sales.Units * products.Product_Cost) AS Total_Profit,
    ((SUM(sales.units * products.product_price) - SUM(sales.Units * products.Product_Cost)) / SUM(sales.units * products.product_price)) * 100 
    AS Profit_Margin_Percentage
FROM
    sales AS sales 
JOIN
    products AS products ON sales.Product_ID = products.Product_ID
GROUP BY
    products.Product_ID;
