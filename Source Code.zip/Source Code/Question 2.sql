

SELECT 
	sales.Product_ID, products.Product_Name, SUM(sales.Units) as Total_Units_Sold
FROM
    sales AS sales 
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GRoup BY
	sales.Product_ID, products.Product_Name
ORDER BY
	Total_Units_Sold DESC;
