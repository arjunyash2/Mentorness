SELECT 
    inventory.Product_ID,
    products.Product_Name,
    stores.Store_Name
FROM
	inventory AS inventory
JOIN
	stores as stores on inventory.Store_ID = stores.Store_ID
JOIN
    products AS products ON inventory.Product_ID = products.Product_ID
WHERE
	inventory.Stock_On_Hand = 0;
