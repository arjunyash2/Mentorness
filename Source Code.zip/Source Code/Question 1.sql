SELECT 
	store.store_id, store.store_name, SUM(sales.units * products.product_price) as Revenue
FROM
	stores AS store
    JOIN
    	sales AS sales on sales.Store_ID = store.Store_ID 
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GRoup BY
	sales.Store_ID
ORDER BY
	Revenue DESC;
	