SELECT  
    stores.Store_Name,
    products.Product_Name,
    inventory.Stock_On_Hand
FROM
	inventory AS inventory
    JOIN
    	products AS products on inventory.Product_ID = products.Product_ID
    JOIN
    	stores as stores on inventory.Store_ID = stores.Store_ID
