SELECT
	products.Product_ID,
    products.Product_Name,
    SUM(sales.Units) AS Total_Units_Sold,
    SUM(inventory.Stock_On_Hand) AS Current_Stock_Level,
    CASE
        WHEN inventory.Stock_On_Hand = 0 THEN 'Out of Stock'
        ELSE ROUND(SUM(sales.Units) / inventory.Stock_On_Hand, 2)
    END AS Sales_To_Stock_Ratio
FROM
    products
JOIN
    sales ON products.Product_ID = sales.Product_ID
JOIN
    inventory ON products.Product_ID = inventory.Product_ID
GROUP BY
    products.Product_ID
ORDER BY
    Total_Units_Sold DESC;
