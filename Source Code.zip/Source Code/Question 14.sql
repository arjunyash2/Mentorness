SELECT 
    stores.Store_Name,
    SUM(sales.Units * products.Product_Price) AS Store_Revenue,
    (SUM(sales.Units * products.Product_Price) /
        (SELECT SUM(sales_inner.Units * products.Product_Price)
         FROM sales AS sales_inner
         JOIN products AS products_inner ON sales_inner.Product_ID = products_inner.Product_ID)) * 100 AS Percentage_of_Total_Revenue
FROM 
    sales
JOIN 
    stores ON sales.Store_ID = stores.Store_ID
JOIN 
    products ON sales.Product_ID = products.Product_ID
GROUP BY 
    stores.Store_Name
ORDER BY 
    Percentage_of_Total_Revenue DESC;
