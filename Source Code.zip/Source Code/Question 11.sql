SELECT 
	products.Product_Category, 
    AVG(products.product_cost)
FROM
    products AS products
GROUP BY
	products.Product_Category;
