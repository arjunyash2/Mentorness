SELECT 
    stores.Store_City, 
    SUM(sales.units * products.product_price) AS Revenue
FROM
    sales AS sales
JOIN
	stores as stores on sales.Store_ID = stores.Store_ID
JOIN
    products AS products ON sales.Product_ID = products.Product_ID
GROUP BY
    stores.Store_City
Order BY
	Revenue DeSC;