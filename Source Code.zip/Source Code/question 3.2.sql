SELECT 
	products.Product_Category, SUM(sales.units * products.product_price) as Revenue
FROM
    	sales AS sales
    JOIN
    	products AS products on sales.Product_ID = products.Product_ID
GROUP BY
	products.Product_Category
ORDER BY
	Revenue DESC;
