SELECT 
    stores.Store_Name,
    stores.Store_Open_Date,
    (julianday('now') - julianday(stores.Store_Open_Date)) / 365 AS Store_Age_Years,
    SUM(sales.Units * products.Product_Price) AS Total_Revenue
FROM
    sales
JOIN 
    stores ON sales.Store_ID = stores.Store_ID
JOIN 
    products ON sales.Product_ID = products.Product_ID
GROUP BY
    stores.Store_ID
ORDER BY
    Store_Age_Years;

