CREATE TABLE 'products' ('Product_ID' INTEGER,'Product_Name' TEXT,'Product_Category' TEXT,'Product_Cost' INTEGER,'Product_Price' INTEGER);
INSERT INTO 'products' ('Product_ID','Product_Name','Product_Category','Product_Cost','Product_Price') VALUES 
 ('1','Action Figure','Toys','$9.99','$15.99'), 
 ('2','Animal Figures','Toys','$9.99','$12.99'), 
 ('3','Barrel O'' Slime','Art & Crafts','$1.99','$3.99'), 
 ('4','Chutes & Ladders','Games','$9.99','$12.99'), 
 ('5','Classic Dominoes','Games','$7.99','$9.99'), 
 ('6','Colorbuds','Electronics','$6.99','$14.99'), 
 ('7','Dart Gun','Sports & Outdoors','$11.99','$15.99'), 
 ('8','Deck Of Cards','Games','$3.99','$6.99'), 
 ('9','Dino Egg','Toys','$9.99','$10.99'), 
 ('10','Dinosaur Figures','Toys','$10.99','$14.99'), 
 ('11','Etch A Sketch','Art & Crafts','$10.99','$20.99'), 
 ('12','Foam Disk Launcher','Sports & Outdoors','$8.99','$11.99'), 
 ('13','Gamer Headphones','Electronics','$14.99','$20.99'), 
 ('14','Glass Marbles','Games','$5.99','$10.99'), 
 ('15','Hot Wheels 5-Pack','Toys','$3.99','$5.99'), 
 ('16','Jenga','Games','$2.99','$9.99'), 
 ('17','Kids Makeup Kit','Art & Crafts','$13.99','$19.99'), 
 ('18','Lego Bricks','Toys','$34.99','$39.99'), 
 ('19','Magic Sand','Art & Crafts','$13.99','$15.99'), 
 ('20','Mini Basketball Hoop','Sports & Outdoors','$8.99','$24.99'), 
 ('21','Mini Ping Pong Set','Sports & Outdoors','$6.99','$9.99'), 
 ('22','Monopoly','Games','$13.99','$19.99'), 
 ('23','Mr. Potatohead','Toys','$4.99','$9.99'), 
 ('24','Nerf Gun','Sports & Outdoors','$14.99','$19.99'), 
 ('25','PlayDoh Can','Art & Crafts','$1.99','$2.99'), 
 ('26','PlayDoh Playset','Art & Crafts','$20.99','$24.99'), 
 ('27','PlayDoh Toolkit','Art & Crafts','$3.99','$4.99'), 
 ('28','Playfoam','Art & Crafts','$3.99','$10.99'), 
 ('29','Plush Pony','Toys','$8.99','$19.99'), 
 ('30','Rubik''s Cube','Games','$17.99','$19.99'), 
 ('31','Splash Balls','Sports & Outdoors','$7.99','$8.99'), 
 ('32','Supersoaker Water Gun','Sports & Outdoors','$11.99','$14.99'), 
 ('33','Teddy Bear','Toys','$10.99','$12.99'), 
 ('34','Toy Robot','Electronics','$20.99','$25.99'), 
 ('35','Uno Card Game','Games','$3.99','$7.99');
 
UPDATE products
SET product_price = REPLACE(product_price, '$', '');

UPDATE products
SET product_cost = REPLACE(product_cost, '$', '');