SELECT
    sales.Date,
    SUM(sales.Units) AS Total_Units_Sold
FROM
    sales
GROUP BY
    sales.Date
ORDER BY
    sales.Date;
